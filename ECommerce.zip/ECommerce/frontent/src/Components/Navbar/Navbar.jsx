import React, { useContext, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Navbar.css";
import logo from "../../assets/logo.png";
import cart_icon from "../../assets/cart_icon.png";
import { Link } from "react-router-dom";
import { ShopContext } from "../../Context/ShopContext";
import arrow_icon from "../../assets/breadcrum_arrow.png";

export default function Navbar() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [menu, setMenu] = useState("Shop");
  const menuRef = useRef();
  const dropdown_toggle = (e) => {
    menuRef.current.classList.toggle("nav-menu-visible");
    e.target.classList.toggle("open");
  };
  const linkStyle = {
    textDecoration: "none",
  };
  const { getTotalCartItems } = useContext(ShopContext);

  //!for checking admin is or not
  useEffect(() => {
    if (localStorage.getItem("auth-token")) {
      try {
        fetch("http://localhost:8000/getauth", {
          method: "POST",
          headers: {
            Accept: "application/form-data",
            "auth-token": `${localStorage.getItem("auth-token")}`,
            "Content-Type": "application/json",
          },
          body: "",
        })
          .then((response) => response.json())
          .then((data) => {
            console.log("data for isAdmin or not  : ", data);
            setIsAdmin(data.Admin);
          });
      } catch (error) {
        console.log(error);
      }
    }
  }, []);

  const logout = () => {
    localStorage.removeItem("auth-token");
    navigate("/");
    window.location.reload();
    //* window.location.replace("/") replaces the current entry in the history stack with the new one (the new path or URL), without creating a new entry
  };
  return (
    <>
      <div className="navbar">
        <div className="nav-logo">
          <img src={logo} alt="" />
          <p>SHOPPER</p>
        </div>
        <img
          className="nav-dropdown"
          onClick={dropdown_toggle}
          src={arrow_icon}
          alt="dorpDown-image"
        />
        <ul ref={menuRef} className="nav-menu">
          <li onClick={() => setMenu("Shop")}>
            <Link style={linkStyle} to="/">
              Shop
            </Link>
            {menu === "Shop" && <hr />}
          </li>
          <li onClick={() => setMenu("Men")}>
            <Link style={linkStyle} to="/mens">
              Men
            </Link>
            {menu === "Men" && <hr />}
          </li>
          <li onClick={() => setMenu("Women")}>
            <Link style={linkStyle} to="/womens">
              Women
            </Link>
            {menu === "Women" && <hr />}
          </li>
          <li onClick={() => setMenu("Kid")}>
            <Link style={linkStyle} to="/kids">
              Kid
            </Link>
            {menu === "Kid" && <hr />}
          </li>
          {isAdmin ? (
            <li onClick={() => setMenu("Admin")}>
              <Link style={linkStyle} to="/admins">
                Admin
              </Link>
              {menu === "Admin" && <hr />}
            </li>
          ) : (
            ""
          )}
        </ul>
        <div className="nav-login-cart">
          {localStorage.getItem("auth-token") ? (
            <button
              onClick={() => {
                logout();
              }}
            >
              Logout
            </button>
          ) : (
            <button>
              <Link style={linkStyle} to="/login">
                Login
              </Link>
            </button>
          )}
          <Link style={linkStyle} to="/cart">
            <img src={cart_icon} alt="" />
          </Link>
          <div className="nav-cart-count">{getTotalCartItems()}</div>
        </div>
      </div>
    </>
  );
}

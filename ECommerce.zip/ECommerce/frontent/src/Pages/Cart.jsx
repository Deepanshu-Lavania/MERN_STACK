import React from 'react'
import CartItems from '../Components/CartItems/CartItems'

export default function Cart() {
  return (
    <>
     <CartItems/> 
    </>
  )
}
